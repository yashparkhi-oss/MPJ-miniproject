package project.controller;

import java.lang.management.ManagementFactory;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sun.management.OperatingSystemMXBean;

import project.entity.Expense;
import project.entity.User;
import project.repository.ExpenseRepo;
import project.repository.TripRepo;
import project.repository.UserRepo;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserRepo userRepo;
    @Autowired
    private TripRepo tripRepo;
    @Autowired
    private ExpenseRepo expenseRepo;

    @GetMapping("/dashboard")
    public String adminDashboard(@RequestParam(value = "search", required = false) String search, 
                                Model model, Principal principal) {
        try {
            // 1. System Statistics (Real Data)
            OperatingSystemMXBean osBean = ManagementFactory.getPlatformMXBean(OperatingSystemMXBean.class);
            double cpuLoad = osBean.getCpuLoad() * 100;
            long totalMem = osBean.getTotalMemorySize() / (1024 * 1024);
            long freeMem = osBean.getFreeMemorySize() / (1024 * 1024);
            
            model.addAttribute("cpuUsage", String.format("%.1f", cpuLoad));
            model.addAttribute("memUsage", totalMem - freeMem);
            model.addAttribute("memTotal", totalMem);
            model.addAttribute("currentAdmin", principal.getName()); // To hide buttons

            // 2. Business Logic Stats
            model.addAttribute("totalUsers", userRepo.count());
            model.addAttribute("totalTrips", tripRepo.count());
            
            double total = expenseRepo.findAll().stream()
                    .mapToDouble(Expense::getAmount).sum();
            model.addAttribute("globalTotal", String.format("%.2f", total));

            // 3. User List with Search
            List<User> users = userRepo.findAll();
            if (search != null && !search.trim().isEmpty()) {
                users = users.stream()
                        .filter(u -> u.getUsername().toLowerCase().contains(search.toLowerCase()))
                        .toList();
            }
            model.addAttribute("users", users);
            model.addAttribute("recentActivity", expenseRepo.findAll());

            return "admin-dashboard";
        } catch (Exception e) {
            return "redirect:/login?error=true";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id, Principal principal) {
        User userToDelete = userRepo.findById(id).orElse(null);
        // Safety: Don't let admin delete themselves
        if (userToDelete != null && !userToDelete.getUsername().equals(principal.getName())) {
            userRepo.deleteById(id);
        }
        return "redirect:/admin/dashboard?deleted=true";
    }
}