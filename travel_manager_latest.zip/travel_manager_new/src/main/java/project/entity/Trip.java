package project.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Trip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private double budget;
    private String location;

    // Initializing the list here prevents 500 errors when a new trip has 0 expenses
    @OneToMany(mappedBy = "trip", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Expense> expenses = new ArrayList<>();
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    // --- CONSTRUCTORS ---
    public Trip() {}

    public Trip(String name, double budget, String location, User user) {
        this.name = name;
        this.budget = budget;
        this.location = location;
        this.user = user;
    }

    // --- GETTERS ---
    public Long getId() { return id; }
    public String getName() { return name; }
    public double getBudget() { return budget; }
    public String getLocation() { return location; }
    public List<Expense> getExpenses() { return expenses; }
    public User getUser() { return user; }

    // --- SETTERS ---
    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setBudget(double budget) { this.budget = budget; }
    public void setLocation(String location) { this.location = location; }
    public void setUser(User user) { this.user = user; }
    public void setExpenses(List<Expense> expenses) { this.expenses = expenses; }

    // --- HELPER METHODS ---
    // Useful for your Controller to calculate totals easily
    public double getTotalSpent() {
        if (expenses == null) return 0.0;
        return expenses.stream()
                       .mapToDouble(Expense::getAmount)
                       .sum();
    }

    public double getRemainingBudget() {
        return this.budget - getTotalSpent();
    }
}
