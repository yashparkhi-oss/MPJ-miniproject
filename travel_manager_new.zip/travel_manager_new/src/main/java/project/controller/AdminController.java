package project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import project.repository.UserRepo;
import project.repository.TripRepo;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserRepo userRepo;
    
    @Autowired
    private TripRepo tripRepo;

    @GetMapping("/dashboard")
    public String adminDashboard(Model model) {
        model.addAttribute("users", userRepo.findAll());
        model.addAttribute("totalUsers", userRepo.count());
        model.addAttribute("totalTrips", tripRepo.count());
        return "admin-dashboard"; // Maps to the HTML file provided previously
    }

    @PostMapping("/deleteUser")
    public String deleteUser(@RequestParam Long id) {
        // Safety check: Prevent the admin from deleting themselves (ID 1)
        if (id != 1L) {
            userRepo.deleteById(id);
        }
        return "redirect:/admin/dashboard?deleted";
    }
}